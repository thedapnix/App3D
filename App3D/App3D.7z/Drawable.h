#pragma once

#ifdef _DEBUG
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#endif

#include <vector>
#include <DirectXMath.h>

#include "ShaderResource.h" //Gives us d3d11 and wrl
#include "VertexBuffer.h"
#include "IndexBuffer.h"

struct Vertex
{
	DirectX::XMFLOAT3 position;
	DirectX::XMFLOAT2 texcoord;
	DirectX::XMFLOAT3 normal;
};

struct BufferData
{
	struct VertexData
	{
		UINT size;						//sizeof(Vertex)
		UINT count;						//vCount
		std::vector<Vertex> vector;		//
	} vData; //init

	struct IndexData
	{
		UINT size;
		UINT count;						//iCount
		std::vector<UINT> vector;		//
	} iData;

	std::string textureFile;
};

class Drawable
{
public:
	Drawable() = default;
	~Drawable() = default;

	void Init(ID3D11Device* device, const BufferData& data);

	void Bind(ID3D11DeviceContext* context);
	void Draw(ID3D11DeviceContext* context) const;
private:
	//Buffers and srv+srt
	VertexBuffer m_vertexBuffer;
	IndexBuffer m_indexBuffer;
	ShaderResource m_shaderResource;

	UINT m_startIndex = 0;
	//UINT m_iCount = 0;
};