#include "Drawable.h"

void Drawable::Init(ID3D11Device* device, const BufferData& data)
{
	//Every drawable has a vertex buffer, an index buffer, and a constant buffer
	//They can also have shader resource view+texture (realistically everything will be textured but hey, we have the option not to)
	m_vertexBuffer.Init(
		device, 
		data.vData.size, 
		data.vData.count,
		(void*)(data.vData.vector.data())
	);

	m_indexBuffer.Init(
		device, 
		data.iData.size,
		data.iData.count,
		(uint32_t*)(data.iData.vector.data()));

	//m_shaderResource.Init(device, mesh.textureFile.c_str());

	m_startIndex = 0;
	//m_iCount = mesh.indexData.count;
}

void Drawable::Bind(ID3D11DeviceContext* context)
{
	//We get buffer, stride and offset values
	ID3D11Buffer* buffer[] = { m_vertexBuffer.GetBuffer() };
	UINT stride = m_vertexBuffer.GetVertexSize();
	UINT offset = 0;

	//Setting Vertex Buffer
	context->IASetVertexBuffers(0, 1, buffer, &stride, &offset);

	//Setting Index Buffer
	context->IASetIndexBuffer(m_indexBuffer.GetBuffer(), DXGI_FORMAT_R32_UINT, 0);

	// Set the texture
	//ID3D11ShaderResourceView* views[] = { m_shaderResource.GetSRV() };
	//context->PSSetShaderResources(0, 1, views);
}

void Drawable::Draw(ID3D11DeviceContext* context) const
{
	//Index count, start index, "base vertex location" whatever that means
	context->DrawIndexed(m_indexBuffer.GetIndexCount(), m_startIndex, 0);
}